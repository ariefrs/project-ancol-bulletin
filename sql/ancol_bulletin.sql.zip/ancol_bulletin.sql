-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2020 at 03:37 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.1.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ancol_bulletin`
--
CREATE DATABASE IF NOT EXISTS `ancol_bulletin` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ancol_bulletin`;

-- --------------------------------------------------------

--
-- Table structure for table `ancol_banner`
--

DROP TABLE IF EXISTS `ancol_banner`;
CREATE TABLE IF NOT EXISTS `ancol_banner` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL DEFAULT 'banner',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `imageurl` varchar(100) NOT NULL DEFAULT '',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `showBanner` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `custombannercode` text,
  `catid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `sticky` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tags` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`bid`),
  KEY `viewbanner` (`showBanner`),
  KEY `idx_banner_catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_banner`:
--

--
-- Truncate table before insert `ancol_banner`
--

TRUNCATE TABLE `ancol_banner`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_bannerclient`
--

DROP TABLE IF EXISTS `ancol_bannerclient`;
CREATE TABLE IF NOT EXISTS `ancol_bannerclient` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` time DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_bannerclient`:
--

--
-- Truncate table before insert `ancol_bannerclient`
--

TRUNCATE TABLE `ancol_bannerclient`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_bannertrack`
--

DROP TABLE IF EXISTS `ancol_bannertrack`;
CREATE TABLE IF NOT EXISTS `ancol_bannertrack` (
  `track_date` date NOT NULL,
  `track_type` int(10) UNSIGNED NOT NULL,
  `banner_id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_bannertrack`:
--

--
-- Truncate table before insert `ancol_bannertrack`
--

TRUNCATE TABLE `ancol_bannertrack`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_categories`
--

DROP TABLE IF EXISTS `ancol_categories`;
CREATE TABLE IF NOT EXISTS `ancol_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `name` varchar(255) DEFAULT '',
  `alias` varchar(255) DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `section` varchar(50) DEFAULT '',
  `image_position` varchar(30) DEFAULT '',
  `description` text,
  `published` tinyint(1) DEFAULT '0',
  `checked_out` int(11) UNSIGNED DEFAULT '0',
  `checked_out_time` datetime DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `access` tinyint(3) UNSIGNED DEFAULT '0',
  `count` int(11) DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_categories`:
--

--
-- Truncate table before insert `ancol_categories`
--

TRUNCATE TABLE `ancol_categories`;
--
-- Dumping data for table `ancol_categories`
--

INSERT INTO `ancol_categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES
(1, 0, 'Berbagi', '', 'berbagi', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(2, 0, 'Budaya Kerja', '', 'budaya_kerja', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(3, 0, 'Edukasi', '', 'edukasi', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(4, 0, 'Event', '', 'event', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(5, 0, 'Fokus', '', 'fokus', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(6, 0, 'Kabar Kita', '', 'kabar_kita', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(7, 0, 'Partitur', '', 'partitur', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(8, 0, 'Peristiwa', '', 'peristiwa', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(9, 0, 'Perspektif', '', 'perspektif', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(10, 0, 'Resensi', '', 'resensi', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(11, 0, 'Santap', '', 'santap', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(12, 0, 'Sosok', '', 'sosok', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(13, 0, 'Tahukah Anda', '', 'tahukah_anda', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(14, 0, 'Terkini', '', 'terkini', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL),
(15, 0, 'Tips', '', 'tips', '', '', '', NULL, 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ancol_components`
--

DROP TABLE IF EXISTS `ancol_components`;
CREATE TABLE IF NOT EXISTS `ancol_components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `parent` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `admin_menu_link` varchar(255) NOT NULL DEFAULT '',
  `admin_menu_alt` varchar(255) NOT NULL DEFAULT '',
  `option` varchar(50) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `admin_menu_img` varchar(255) NOT NULL DEFAULT '',
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `parent_option` (`parent`,`option`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_components`:
--

--
-- Truncate table before insert `ancol_components`
--

TRUNCATE TABLE `ancol_components`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_contact_details`
--

DROP TABLE IF EXISTS `ancol_contact_details`;
CREATE TABLE IF NOT EXISTS `ancol_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `imagepos` varchar(20) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `published` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_contact_details`:
--

--
-- Truncate table before insert `ancol_contact_details`
--

TRUNCATE TABLE `ancol_contact_details`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_content`
--

DROP TABLE IF EXISTS `ancol_content`;
CREATE TABLE IF NOT EXISTS `ancol_content` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `alias` varchar(255) DEFAULT '',
  `title_alias` varchar(255) DEFAULT '',
  `introtext` mediumtext,
  `completetext` mediumtext,
  `state` tinyint(3) DEFAULT '0',
  `sectionid` int(11) UNSIGNED DEFAULT '0',
  `mask` int(11) UNSIGNED DEFAULT '0',
  `catid` int(11) UNSIGNED DEFAULT '0',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) UNSIGNED DEFAULT '0',
  `created_by_alias` varchar(255) DEFAULT '',
  `modified` datetime DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) UNSIGNED DEFAULT '0',
  `checked_out` int(11) UNSIGNED DEFAULT '0',
  `checked_out_time` datetime DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime DEFAULT '0000-00-00 00:00:00',
  `images` text,
  `urls` text,
  `attribs` text,
  `version` int(11) UNSIGNED DEFAULT '1',
  `parentid` int(11) UNSIGNED DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `metakey` text,
  `metadesc` text,
  `access` int(11) UNSIGNED DEFAULT '0',
  `hits` int(11) UNSIGNED DEFAULT '0',
  `metadata` text,
  PRIMARY KEY (`id`),
  KEY `idx_section` (`sectionid`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_content`:
--

--
-- Truncate table before insert `ancol_content`
--

TRUNCATE TABLE `ancol_content`;
--
-- Dumping data for table `ancol_content`
--

INSERT INTO `ancol_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `completetext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(1, 'Ancol dan Forhati Berbagi Ceria Bersama Anak Kampung Sumur Banten', 'ancol-dan-forhati-berbagi-ceria-bersama-anak-kampung-sumur-banten', '', '<p>Bencana tsunami yang melanda pesisir Selat Sunda pada 22 Desember 2018 yang lalu membawa sedikitnya 430 korban meninggal dan 7.000 an korban luka dan...', '<div><img class=\"\" src=\"http://localhost/ancol/images/content/Berbagi.jpg\"></div><div class=\"row\">\r\n    <div class=\"col-md-4\">\r\n    <p>Bencana tsunami yang melanda pesisir Selat Sunda pada 22 Desember 2018 yang lalu membawa sedikitnya 430 korban meninggal dan 7.000 an korban luka dan 30-an orang hilang.</p>\r\n    <p>Tsunami yang diakibatkan oleh longsor dan erupsinya anak Gunung Krakatau itu menyapu pesisir Banten dan Lampung. Di Banten, daerah terparah dialami oleh Kampung Sumur yang terletak di Tanjung Lesung Pandeglang. Korban meninggal dan luka-luka terbesar terjadi di daerah ini.</p>\r\n    <p>Di Kampung Sumur, banyak keluarga kehilangan tempat tinggal akibat tersapu gelombang tsunami. Selain itu di daerah ini juga banyak objek wisata pantai yang ikut tersapu air bah. Penduduk yang menjadi korban mengalami trauma, terutama anak-anak SD di Kampung Sumur.</p>\r\n    </div>\r\n\r\n    <div class=\"col-md-4\">\r\n    <p>PT Pembangunan Jaya Ancol Tbk (Ancol) bersama dengan Majelis Nasional Forum Alumni HMI Wati (FORHATI) mengundang 100 anak dari Kampung Sumur, Pandeglang, Banten berekreasi di Ancol Taman Impian.</p>\r\n    <p>Kegiatan yang bernama &ldquo;Menjemput Impian Bersama&rdquo; ini dilaksanakan pada Selasa, 26 Februari 2019 di Clubhouse Allianz Ecopark, Ancol. Acara dibuka pukul 09.00 pagi dan disambut oleh Direktur Utama Ancol, C. Paul Tehusijarana.</p>\r\n    <p>Mereka adalah anak-anak yang terdampak bencana tsunami di Pandeglang, Banten. Seluruh peserta terdiri dari siswa kelas 3 &ndash; 6 SD yang didampingi oleh Guru SD Taman Jaya Kampung Sumur.</p>\r\n    </div>\r\n\r\n    <div class=\"col-md-4\">\r\n    <p>Mereka diboyong ke Dunia Fantasi Ancol untuk menikmati seluruh permainan dan wahana yang ada di kawasan rekreasi. Setelah melalui pengalaman bencana alam yang tidak pernah mereka harapkan, hari ini anak-anak tersebut akan terhibur dengan wahana seru dan menyenangkan.</p>\r\n    <p>&ldquo;Kami harap kegiatan hari ini bisa menghibur serta menambah wawasan dan juga membantu anak-anak dalam memulihkan kondisi psikologisnya&rdquo; ucap Paul.</p>\r\n    <p>Sehari sebelumnya, Senin (25/2/2019) Forhati juga telah melaksanakan psiko sosial di SD Taman Jaya Kampung Sumur. Acara diisi dengan beragam permainan, kesenian origami, bernyanyi serta pengajaran bahasa inggris untuk anak-anak PAUD serta anak kelas 1 dan 2 SD.</p>\r\n    </div>\r\n</div>\r\n', 0, 1, 0, 1, '2019-03-10 23:27:55', 0, '', '2019-03-10 23:27:55', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'images/content/Berbagi.jpg', NULL, NULL, 1, 0, 0, NULL, NULL, 0, 49, NULL),
(3, 'Manajemen Jangan Tunda Pekerjaan', 'manajemen-jangan-tunda-pekerjaan', '', 'Setiap orang cenderung menunda pekerjaan, apa pun alasannya. Akan tetapi, ', '    <section id=\"hotels\" class=\"section-with-bg wow fadeInUp\">\r\n      <div class=\"container\">\r\n        <div class=\"row\">\r\n          <p>Setiap orang cenderung menunda pekerjaan, apa pun alasannya. Akan tetapi, bila menunda mulai membuat cemas dan lingkungan kerja bereaksi negatif, hati hati! Bisa jadi ini saatnya Anda mengintrospeksi diri. </p>\r\n          <p>Jika Anda menemui masalah seperti di atas, Himawan Wijanarko, General Manager Strategic Services The Jakarta Consulting Group, menyarankan untuk berstrategi mengurai sindrom prokrastinasi yang melilit. Berikut kiat-kiatnya:</p>\r\n        </div>\r\n\r\n        <div class=\"row\">\r\n          <div class=\"col-lg-4 col-md-6\">\r\n            <div class=\"hotel\">\r\n              <div class=\"hotel-img\">\r\n                <img src=\"http://localhost/ancol/images/content/Manajemen.jpg\" alt=\"Manajemen\" class=\"img-responsive\">\r\n              </div>\r\n              <h3><a href=\"#\"></a></h3>\r\n              <p></p>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"col-lg-4 col-md-6\">\r\n            <div class=\"hotel\">\r\n              <div class=\"hotel-img\">\r\n                <img src=\"http://localhost/ancol/images/content/Manajemen1.jpg\" alt=\"Manajemen 1\" class=\"img-responsive\">\r\n              </div>\r\n              <h3><a href=\"#\"></a></h3>\r\n              <p></p>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"col-lg-4 col-md-6\">\r\n            <div class=\"hotel\">\r\n              <div class=\"hotel-img\">\r\n                <img src=\"http://localhost/ancol/images/content/Manajemen2.jpg\" alt=\"Manajemen 2\" class=\"img-responsive\">\r\n              </div>\r\n              <h3><a href=\"#\"></a></h3>\r\n              <p></p>\r\n            </div>\r\n          </div>\r\n\r\n        </div>\r\n        <div class=\"row\">\r\n            <div class=\"col-md-6\">\r\n                    <h4>1. Manajemen Diri</h4>\r\n                    <p>Setiap orang memang memiliki kecenderungan menunda pekerjaan. Ini bisa saja disebabkan faktor kurang dalam kemampuan mengatur diri. Orang dengan kecenderungan ini biasanya sulit mengklasifikasikan mana urusan yang penting dan tidak terlalu penting.</p> \r\n                    <p>Akibatnya semua permasalahan tidak diletakkan dalam skala prioritas yang tepat. Mulai dari pengukuran kemampuan menyelesaikan suatu pekerjaan, perhitungan beban pekerjaan, dan prioritas deadlinepekerjaan itu sendiri.</p>\r\n                    <p>Kebanyakan orang yang terjebak dalam penundaan pekerjaan disebabkan oleh kecenderungan untuk menyelesaikan pekerjaan yang menyenangkan terlebih dahulu, sedangkan yang sulit belakangan. Sebenarnya ada sisi positif dari menyelesaikan pekerjaan yang mudah terlebih dahulu karena jika memaksakan mengerjakan yang sulit justru bisa membuat pekerjaan tidak selesai-selesai. Kendati demikian, jangan lupakan deadline, dan buat jadwal lebih rapi mengenai pengerjaan tugas perusahaan.</p>            \r\n            </div>\r\n            <div class=\"col-md-6\">\r\n                <h4>2. Manajemen Stress</h4>\r\n                <p>Disadari atau tidak, stres juga bisa mengacaukan akselerasi penyelesaian pekerjaan hingga tak sesuai target. Menurut Himawan, stres pada dasarnya bisa disebabkan empat hal. Pertama, tekanan seperti deadline dan tuntutan kualitas diri. Kedua, frustrasi yang bisa disebabkan oleh hasil yang kurang baik maupun reaksi negatif lingkungan. Ketiga, konflik seperti saat memilah untuk menyelesaikan pekerjaan yang mana lebih dahulu. Keempat, krisis yang bisa disebabkan oleh perubahan yang tiba-tiba.</p>\r\n                <p>Ketika menemui kondisi stres, yang perlu dilakukan adalah mengatasi efek psikologisnya. Petakan permasalahan demi menurunkan level stres hingga ke jenjang yang masuk akal. Jika Anda piawai memetakan permasalahan, dengan sendirinya level stres menurun. Level stres yang masuk akal ini justru bisa meningkatkan produktivitas seseorang karena stres sebenarnya juga berperan meningkatkan gairah untuk lebih produktif.</p>\r\n\r\n            </div>\r\n        </div>\r\n      </div>\r\n\r\n    </section>', 0, 1, 0, 2, '2019-03-11 02:06:05', 0, '', '2019-03-11 02:06:05', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'images/content/Manajemen1.jpg', NULL, NULL, 1, 0, 0, NULL, NULL, 0, 23, NULL),
(4, 'Manfaat Kunjungi Wisata Budaya', 'manfaat-kunjungi-wisata-budaya', '', '<p>&nbsp;</p>\r\n\r\n<p>Wisata budaya nampaknya kurang diminati oleh masyarakat modern, termasuk anak muda. Sebagian besar dari mereka menganggap kalau tempat...', '<div class=\\\"col-md-6\\\">\r\n<p>Wisata budaya nampaknya kurang diminati oleh masyarakat modern, termasuk anak muda. Sebagian besar dari mereka menganggap kalau tempat tersebut kuno, kurang menarik, tak ada hal seru didapatkan atau lain sebagainya.</p>\r\n\r\n<p>Anggapan tersebut kemudian tertular ke orang lain sehingga membuat beberapa destinasi wisata budaya tradisional menjadi sepi pengunjung.</p>\r\n\r\n<p>Akibatnya fatal dimana Indonesia bakal kehilangan identitas secara perlahan karena tergerus perkembangan zaman ditambah lagi penduduknya tak mau ikut melestarikan budaya peninggalan nenek moyang. Padahal ada begitu banyak manfaat kalau kita traveling ke suatu wisata budaya, diantaranya:</p>\r\n</div>\r\n<div class=\\\"col-md-6\\\">\r\n<p>Belajar mengenai kebudayaan tempat lain, mulai dari tradisi sehari-hari, makanan tradisional, dan upacara adat Mendapatkan nilai moral berharga lewat tindak tanduk para penduduknya. Menumbuhkan rasa bangga sekaligus cinta terhadap negara sendiri karena hanya Indonesia yang dianugerahi ratusan lebih jenis budaya.</p>\r\n\r\n<p>Pikiran menjadi lebih luas dan tidak kaku karena paham betul jika dunia ini tak seluas daun kelor. Bertemu dengan orang lain dari berbagai daerah atau negara sekalipun. Ajak mereka berkomunikasi dan berbagai ilmu bahkan pengalaman supaya saling mendapatkan keutungan.</p>\r\n</div>', 0, 2, 0, 3, '2019-03-11 02:48:08', 0, '', '2019-03-11 02:48:08', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'images/content/Budaya3.jpg', NULL, NULL, 1, 0, 0, NULL, NULL, 0, 111, NULL),
(5, 'Test Content 3', 'test-content-3', '', '<div style=\"font-family: Consolas, &quot;Courier New&quot;, monospace, Calibri; font-size: 12px; line-height: 16px; white-space: pre;\"><span style=\"color:...', '<div style=\"font-family: Consolas, &quot;Courier New&quot;, monospace, Calibri; font-size: 12px; line-height: 16px; white-space: pre;\"><span style=\"color: rgb(206, 198, 206); font-family: Tahoma; font-size: 14px;\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad consequatur et beatae repudiandae voluptate pariatur nemo assumenda nostrum nam dignissimos quam consequuntur, officiis quis. Blanditiis eius pariatur tempore quibusdam provident a consequatur quaerat officiis ea, impedit sapiente eum minima dolores nam</span><span style=\"font-family: Tahoma; font-size: 14px;\">﻿</span><span style=\"color: rgb(206, 198, 206); font-family: Tahoma; font-size: 14px;\">. Provident voluptates dicta voluptatum debitis hic rerum, non blanditiis?</span></div>', 0, 9, 0, 15, '2019-03-13 12:11:01', 0, '', '2019-03-13 12:11:01', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL, NULL, 1, 0, 0, NULL, NULL, 0, 2, NULL),
(6, 'Test Content 4', 'test-content-4', '', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Rerum id numquam quaerat deleniti mollitia alias porro quibusdam ipsum consectetur ut exercitationem nesciunt optio reiciendis ullam, totam quisquam minima eius eligendi fugit illum. Quis repellendus inventore accusantium illo dolorem magnam eos consequatur modi natus aspernatur, expedita cupiditate, ea, rerum voluptatum. Repellendus cum cupiditate deserunt! Dolor, repellat nulla provident numquam totam nobis sapiente, sunt ducimus dolorem adipisci delectus ullam corrupti sit, labore sed nam odio eaque sint!', '<div class=\"row\">\r\n    <div class=\"col-md-6\">\r\n        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Rerum id numquam quaerat deleniti mollitia alias porro quibusdam ipsum consectetur ut exercitationem nesciunt optio reiciendis ullam, totam quisquam minima eius eligendi fugit illum. Quis repellendus inventore accusantium illo dolorem magnam eos consequatur modi natus aspernatur, expedita cupiditate, ea, rerum voluptatum. Repellendus cum cupiditate deserunt! Dolor, repellat nulla provident numquam totam nobis sapiente, sunt ducimus dolorem adipisci delectus ullam corrupti sit, labore sed nam odio eaque sint!</p></div>\r\n    <div class=\"col-md-6\">\r\n        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quod officiis magni eius facilis iste, est nostrum, atque, consectetur itaque corporis eveniet incidunt voluptas autem voluptates. Dolorem magni libero suscipit delectus quas, maxime tempora amet, eaque provident necessitatibus architecto laboriosam. Labore placeat voluptas, omnis ducimus eius quia modi tenetur qui earum voluptate distinctio, a optio, expedita saepe debitis. Nihil, facere asperiores pariatur quisquam optio quam, porro rem fuga, sequi consequuntur aut! Fugit sed pariatur recusandae? Reiciendis distinctio harum quaerat fuga id sequi debitis nobis, ipsam repellat a quisquam placeat dolorum blanditiis quis voluptates minima optio enim ab deserunt totam nam. Illo dolorem minima repellendus dignissimos voluptate quis saepe modi, reprehenderit debitis obcaecati, voluptatem neque magni quod ipsum nulla molestiae aliquam nobis harum tenetur? Sit, quisquam nobis!</p></div>\r\n</div>\r\n<div class=\"row\">\r\n    <div class=\"col-md-4\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed, sequi consequatur. Minima, esse laboriosam in incidunt illum vero veritatis consectetur deserunt odit, inventore animi voluptatem provident? Quia consectetur libero, nesciunt necessitatibus repellendus, beatae fugiat quisquam illum velit odio nulla doloremque tenetur dignissimos molestias quasi aliquid.</div>\r\n    <div class=\"col-md-4\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed, sequi consequatur. Minima, esse laboriosam in incidunt illum vero veritatis consectetur deserunt odit, inventore animi voluptatem provident? Quia consectetur libero, nesciunt necessitatibus repellendus, beatae fugiat quisquam illum velit odio nulla doloremque tenetur dignissimos molestias quasi aliquid.</div>\r\n    <div class=\"col-md-4\">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed, sequi consequatur. Minima, esse laboriosam in incidunt illum vero veritatis consectetur deserunt odit, inventore animi voluptatem provident? Quia consectetur libero, nesciunt necessitatibus repellendus, beatae fugiat quisquam illum velit odio nulla doloremque tenetur dignissimos molestias quasi aliquid.</div>\r\n</div>\r\n<div class=\"row\">\r\n    <div class=\"col-md-12\"><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur, quasi? Quo unde obcaecati, quod nostrum rerum, blanditiis est iusto ipsam aliquid, temporibus excepturi omnis. Ad ipsum rem, tempora quaerat doloribus rerum veniam enim laborum minus beatae nulla repudiandae illo vitae fuga ea expedita dolorum sit minima at quam possimus aliquid placeat. Doloribus, quam nam iusto tenetur, ad eaque exercitationem non commodi necessitatibus aliquid quis voluptatem hic vitae modi in dicta delectus neque placeat fugit saepe explicabo tempore repellendus? Consequuntur ab provident aspernatur veniam molestiae delectus iusto nisi praesentium obcaecati recusandae debitis commodi reiciendis vitae rerum, quod cupiditate accusantium. Incidunt reprehenderit consectetur unde numquam provident, mollitia perferendis saepe delectus, dignissimos in aperiam quae corporis eum est deserunt nisi nostrum voluptatibus autem vel iure assumenda. Aspernatur unde sapiente alias libero, quaerat labore pariatur porro officiis recusandae possimus harum, quisquam voluptate officia qui tenetur ipsam, odio eaque facere? Eos non culpa ratione impedit nulla commodi illum soluta voluptatum, ad repudiandae assumenda perferendis, accusamus ut quisquam perspiciatis odio repellat neque doloribus! Et voluptate esse omnis temporibus veritatis non, error quae consequatur earum sit maxime dolorum minima, magnam repudiandae minus nesciunt, tenetur ullam quo eaque eum voluptates mollitia suscipit totam accusamus. Eius aut fugiat nam minima earum iusto doloremque, modi consequatur? Possimus expedita rem voluptatibus architecto corporis doloribus porro fugiat asperiores optio distinctio iure perspiciatis perferendis inventore, eligendi quam. Laboriosam praesentium dolores ea tempora fugiat asperiores esse iure soluta veritatis dolorum in rerum pariatur quaerat, minus debitis qui tempore alias quibusdam? Dolorem possimus ad quo numquam mollitia architecto repellendus nemo, quas, soluta corporis qui sed earum dolores cum pariatur assumenda vero! Blanditiis sit aliquid quibusdam dolore cupiditate sapiente consequatur, facilis atque alias deleniti iusto libero, magnam consequuntur quo natus magni illum laudantium! Id tempora dolores repudiandae porro quisquam at consectetur accusamus. Quae aliquam officiis atque quibusdam fuga pariatur magnam perferendis. Odio cum, quisquam eos officiis architecto unde iure a inventore. Fugiat, esse, a quos eveniet corrupti odio qui dolores dolor quo vel quibusdam? Temporibus delectus obcaecati quibusdam neque voluptas quia quasi maxime recusandae sunt veritatis voluptatibus reprehenderit cum ducimus officiis, facere numquam aliquam ipsa optio!</p></div>\r\n</div>', 0, 9, 0, 15, '2019-03-13 13:00:39', 0, '', '2019-03-13 13:00:39', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, NULL, NULL, 1, 0, 0, NULL, NULL, 0, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ancol_content_frontpage`
--

DROP TABLE IF EXISTS `ancol_content_frontpage`;
CREATE TABLE IF NOT EXISTS `ancol_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_content_frontpage`:
--

--
-- Truncate table before insert `ancol_content_frontpage`
--

TRUNCATE TABLE `ancol_content_frontpage`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_content_rating`
--

DROP TABLE IF EXISTS `ancol_content_rating`;
CREATE TABLE IF NOT EXISTS `ancol_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `rating_count` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_content_rating`:
--

--
-- Truncate table before insert `ancol_content_rating`
--

TRUNCATE TABLE `ancol_content_rating`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_core_acl_aro`
--

DROP TABLE IF EXISTS `ancol_core_acl_aro`;
CREATE TABLE IF NOT EXISTS `ancol_core_acl_aro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_value` varchar(240) NOT NULL DEFAULT '0',
  `value` varchar(240) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ancol_section_value_value_aro` (`section_value`(100),`value`(100)),
  KEY `ancol_gacl_hidden_aro` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_core_acl_aro`:
--

--
-- Truncate table before insert `ancol_core_acl_aro`
--

TRUNCATE TABLE `ancol_core_acl_aro`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_core_acl_aro_groups`
--

DROP TABLE IF EXISTS `ancol_core_acl_aro_groups`;
CREATE TABLE IF NOT EXISTS `ancol_core_acl_aro_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ancol_gacl_parent_id_aro_groups` (`parent_id`),
  KEY `ancol_gacl_lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_core_acl_aro_groups`:
--

--
-- Truncate table before insert `ancol_core_acl_aro_groups`
--

TRUNCATE TABLE `ancol_core_acl_aro_groups`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_core_acl_aro_map`
--

DROP TABLE IF EXISTS `ancol_core_acl_aro_map`;
CREATE TABLE IF NOT EXISTS `ancol_core_acl_aro_map` (
  `acl_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(230) NOT NULL DEFAULT '0',
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_core_acl_aro_map`:
--

--
-- Truncate table before insert `ancol_core_acl_aro_map`
--

TRUNCATE TABLE `ancol_core_acl_aro_map`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_core_acl_aro_sections`
--

DROP TABLE IF EXISTS `ancol_core_acl_aro_sections`;
CREATE TABLE IF NOT EXISTS `ancol_core_acl_aro_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(230) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(230) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ancol_gacl_value_aro_sections` (`value`),
  KEY `ancol_gacl_hidden_aro_sections` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_core_acl_aro_sections`:
--

--
-- Truncate table before insert `ancol_core_acl_aro_sections`
--

TRUNCATE TABLE `ancol_core_acl_aro_sections`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_core_acl_groups_aro_map`
--

DROP TABLE IF EXISTS `ancol_core_acl_groups_aro_map`;
CREATE TABLE IF NOT EXISTS `ancol_core_acl_groups_aro_map` (
  `group_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(240) NOT NULL DEFAULT '',
  `aro_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `group_id_aro_id_groups_aro_map` (`group_id`,`section_value`,`aro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_core_acl_groups_aro_map`:
--

--
-- Truncate table before insert `ancol_core_acl_groups_aro_map`
--

TRUNCATE TABLE `ancol_core_acl_groups_aro_map`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_core_log_items`
--

DROP TABLE IF EXISTS `ancol_core_log_items`;
CREATE TABLE IF NOT EXISTS `ancol_core_log_items` (
  `time_stamp` date NOT NULL DEFAULT '0000-00-00',
  `item_table` varchar(50) NOT NULL DEFAULT '',
  `item_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hits` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_core_log_items`:
--

--
-- Truncate table before insert `ancol_core_log_items`
--

TRUNCATE TABLE `ancol_core_log_items`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_core_log_searches`
--

DROP TABLE IF EXISTS `ancol_core_log_searches`;
CREATE TABLE IF NOT EXISTS `ancol_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_core_log_searches`:
--

--
-- Truncate table before insert `ancol_core_log_searches`
--

TRUNCATE TABLE `ancol_core_log_searches`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_groups`
--

DROP TABLE IF EXISTS `ancol_groups`;
CREATE TABLE IF NOT EXISTS `ancol_groups` (
  `id` int(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_groups`:
--

--
-- Truncate table before insert `ancol_groups`
--

TRUNCATE TABLE `ancol_groups`;
--
-- Dumping data for table `ancol_groups`
--

INSERT INTO `ancol_groups` (`id`, `name`) VALUES
(1, 'visitors'),
(2, 'member'),
(3, 'administrator'),
(4, 'super administrator');

-- --------------------------------------------------------

--
-- Table structure for table `ancol_menu`
--

DROP TABLE IF EXISTS `ancol_menu`;
CREATE TABLE IF NOT EXISTS `ancol_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text,
  `type` varchar(50) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `parent` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `componentid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `sublevel` int(11) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pollid` int(11) NOT NULL DEFAULT '0',
  `browserNav` tinyint(4) DEFAULT '0',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `utaccess` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `lft` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `rgt` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `home` int(1) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `componentid` (`componentid`,`menutype`,`published`,`access`),
  KEY `menutype` (`menutype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_menu`:
--

--
-- Truncate table before insert `ancol_menu`
--

TRUNCATE TABLE `ancol_menu`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_menu_types`
--

DROP TABLE IF EXISTS `ancol_menu_types`;
CREATE TABLE IF NOT EXISTS `ancol_menu_types` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `menutype` (`menutype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_menu_types`:
--

--
-- Truncate table before insert `ancol_menu_types`
--

TRUNCATE TABLE `ancol_menu_types`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_messages`
--

DROP TABLE IF EXISTS `ancol_messages`;
CREATE TABLE IF NOT EXISTS `ancol_messages` (
  `message_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_id_to` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `folder_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` int(11) NOT NULL DEFAULT '0',
  `priority` int(1) UNSIGNED NOT NULL DEFAULT '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_messages`:
--

--
-- Truncate table before insert `ancol_messages`
--

TRUNCATE TABLE `ancol_messages`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_messages_cfg`
--

DROP TABLE IF EXISTS `ancol_messages_cfg`;
CREATE TABLE IF NOT EXISTS `ancol_messages_cfg` (
  `user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_messages_cfg`:
--

--
-- Truncate table before insert `ancol_messages_cfg`
--

TRUNCATE TABLE `ancol_messages_cfg`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_migration_backlinks`
--

DROP TABLE IF EXISTS `ancol_migration_backlinks`;
CREATE TABLE IF NOT EXISTS `ancol_migration_backlinks` (
  `itemid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `sefurl` text NOT NULL,
  `newurl` text NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_migration_backlinks`:
--

--
-- Truncate table before insert `ancol_migration_backlinks`
--

TRUNCATE TABLE `ancol_migration_backlinks`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_modules`
--

DROP TABLE IF EXISTS `ancol_modules`;
CREATE TABLE IF NOT EXISTS `ancol_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) DEFAULT NULL,
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `numnews` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `control` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_modules`:
--

--
-- Truncate table before insert `ancol_modules`
--

TRUNCATE TABLE `ancol_modules`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_modules_menu`
--

DROP TABLE IF EXISTS `ancol_modules_menu`;
CREATE TABLE IF NOT EXISTS `ancol_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_modules_menu`:
--

--
-- Truncate table before insert `ancol_modules_menu`
--

TRUNCATE TABLE `ancol_modules_menu`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_newsfeeds`
--

DROP TABLE IF EXISTS `ancol_newsfeeds`;
CREATE TABLE IF NOT EXISTS `ancol_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `cache_time` int(11) UNSIGNED NOT NULL DEFAULT '3600',
  `checked_out` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `published` (`published`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_newsfeeds`:
--

--
-- Truncate table before insert `ancol_newsfeeds`
--

TRUNCATE TABLE `ancol_newsfeeds`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_plugins`
--

DROP TABLE IF EXISTS `ancol_plugins`;
CREATE TABLE IF NOT EXISTS `ancol_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `element` varchar(100) NOT NULL DEFAULT '',
  `folder` varchar(100) NOT NULL DEFAULT '',
  `access` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `iscore` tinyint(3) NOT NULL DEFAULT '0',
  `client_id` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_folder` (`published`,`client_id`,`access`,`folder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_plugins`:
--

--
-- Truncate table before insert `ancol_plugins`
--

TRUNCATE TABLE `ancol_plugins`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_polls`
--

DROP TABLE IF EXISTS `ancol_polls`;
CREATE TABLE IF NOT EXISTS `ancol_polls` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `voters` int(9) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `lag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_polls`:
--

--
-- Truncate table before insert `ancol_polls`
--

TRUNCATE TABLE `ancol_polls`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_poll_data`
--

DROP TABLE IF EXISTS `ancol_poll_data`;
CREATE TABLE IF NOT EXISTS `ancol_poll_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pollid` int(11) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pollid` (`pollid`,`text`(1))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_poll_data`:
--

--
-- Truncate table before insert `ancol_poll_data`
--

TRUNCATE TABLE `ancol_poll_data`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_poll_date`
--

DROP TABLE IF EXISTS `ancol_poll_date`;
CREATE TABLE IF NOT EXISTS `ancol_poll_date` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `vote_id` int(11) NOT NULL DEFAULT '0',
  `poll_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_poll_date`:
--

--
-- Truncate table before insert `ancol_poll_date`
--

TRUNCATE TABLE `ancol_poll_date`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_poll_menu`
--

DROP TABLE IF EXISTS `ancol_poll_menu`;
CREATE TABLE IF NOT EXISTS `ancol_poll_menu` (
  `pollid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pollid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_poll_menu`:
--

--
-- Truncate table before insert `ancol_poll_menu`
--

TRUNCATE TABLE `ancol_poll_menu`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_sections`
--

DROP TABLE IF EXISTS `ancol_sections`;
CREATE TABLE IF NOT EXISTS `ancol_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '',
  `name` varchar(255) DEFAULT '',
  `alias` varchar(255) DEFAULT '',
  `image` text,
  `scope` varchar(50) DEFAULT '',
  `image_position` varchar(30) DEFAULT '',
  `description` text,
  `published` tinyint(1) DEFAULT '0',
  `checked_out` int(11) UNSIGNED DEFAULT '0',
  `checked_out_time` datetime DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `access` tinyint(3) UNSIGNED DEFAULT '0',
  `count` int(11) DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`),
  KEY `idx_scope` (`scope`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_sections`:
--

--
-- Truncate table before insert `ancol_sections`
--

TRUNCATE TABLE `ancol_sections`;
--
-- Dumping data for table `ancol_sections`
--

INSERT INTO `ancol_sections` (`id`, `title`, `name`, `alias`, `image`, `scope`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `ordering`, `access`, `count`, `params`) VALUES
(1, 'Jan 2019', '', '201901', NULL, '', '', 'Bulletin Ancol Edisi Januari 2019', 1, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(2, 'Feb 2019', '', '201902', NULL, '', '', 'Bulletin Ancol Edisi Februari 2019', 1, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(3, 'Mar 2019', '', '201903', NULL, '', '', 'Bulletin Ancol Edisi Maret 2019', 1, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(4, 'Apr 2019', '', '201904', NULL, '', '', 'Bulletin Ancol Edisi April 2019', 1, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(5, 'Mei 2019', '', '201905', NULL, '', '', 'Bulletin Ancol Edisi Mei 2019', 1, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(6, 'Jun 2019', '', '201906', NULL, '', '', 'Bulletin Ancol Edisi Juni 2019', 1, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(7, 'Jul 2019', '', '201907', NULL, '', '', 'Bulletin Ancol Edisi Juli 2019', 1, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(8, 'Aug 2019', '', '201908', NULL, '', '', 'Bulletin Ancol Edisi Agustus 2019', 0, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(9, 'Sep 2019', '', '201909', NULL, '', '', 'Bulletin Ancol Edisi September 2019', 0, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(10, 'Oct 2019', '', '201910', NULL, '', '', 'Bulletin Ancol Edisi Oktober 2019', 0, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(11, 'Nov 2019', '', '201911', NULL, '', '', 'Bulletin Ancol Edisi Nopember 2019', 0, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL),
(12, 'Dec 2019', '', '201912', NULL, '', '', 'Bulletin Ancol Edisi Desember 2019', 0, 0, '0000-00-00 00:00:00', 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ancol_stats_agents`
--

DROP TABLE IF EXISTS `ancol_stats_agents`;
CREATE TABLE IF NOT EXISTS `ancol_stats_agents` (
  `agent` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hits` int(11) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_stats_agents`:
--

--
-- Truncate table before insert `ancol_stats_agents`
--

TRUNCATE TABLE `ancol_stats_agents`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_templates_menu`
--

DROP TABLE IF EXISTS `ancol_templates_menu`;
CREATE TABLE IF NOT EXISTS `ancol_templates_menu` (
  `template` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menuid`,`client_id`,`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_templates_menu`:
--

--
-- Truncate table before insert `ancol_templates_menu`
--

TRUNCATE TABLE `ancol_templates_menu`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_users`
--

DROP TABLE IF EXISTS `ancol_users`;
CREATE TABLE IF NOT EXISTS `ancol_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usertype` varchar(25) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `gid` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`),
  KEY `gid_block` (`gid`,`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_users`:
--

--
-- Truncate table before insert `ancol_users`
--

TRUNCATE TABLE `ancol_users`;
-- --------------------------------------------------------

--
-- Table structure for table `ancol_weblinks`
--

DROP TABLE IF EXISTS `ancol_weblinks`;
CREATE TABLE IF NOT EXISTS `ancol_weblinks` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`,`published`,`archived`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- RELATIONSHIPS FOR TABLE `ancol_weblinks`:
--

--
-- Truncate table before insert `ancol_weblinks`
--

TRUNCATE TABLE `ancol_weblinks`;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
